Our record-generating program is written in Ruby in two files -- models.rb and record_generator.rb. The dependencies for the program are listed in the Gemfile, and can easily be installed by running �bundle install� on a system configured for Rubygems and Bundler.

The number of each kind of record can be modified at the top of record_generator.rb

To run, type "ruby record_generator.rb"
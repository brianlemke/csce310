SELECT * FROM Library;
SELECT * FROM Customer;
SELECT * FROM Item;
SELECT * FROM Employee;
SELECT * FROM Accesses;
SELECT * FROM Loan;
SELECT * FROM Checkout;